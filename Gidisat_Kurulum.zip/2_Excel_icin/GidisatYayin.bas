Attribute VB_Name = "GidisatYayin"
Option Explicit
'=====================================================================
'  GIDISAT YAYIN MODULU - surum 1.0
'
'  Ne yapar: GIDISAT sayfasindaki tabloyu belirli araliklarla okur,
'  degisiklik varsa GitHub'a gonderir. Personelin telefonundaki
'  uygulama bu dosyayi okur ve kendini yeniler.
'
'  Excel dosyasinda hicbir hucreyi degistirmez, sadece okur.
'  Ayarlar: Excel dosyasinin yanindaki yayin_ayar.txt dosyasindadir.
'
'  Kullanici makrolari (Alt+F8):
'     HemenYayinla  : deneme ve anlik yayin
'     YayinDurumu   : durumu gosterir
'     YayinBaslat   : zamanlayiciyi baslatir
'     YayinDurdur   : zamanlayiciyi durdurur
'
'  Not: Metinlerdeki "~i" gibi isaretler Turkce harf yerine kullanilir
'  (ASCII dosya olsun diye). Tr() islevi bunlari Turkce harfe cevirir.
'=====================================================================

Private Const SURUM As String = "1.0"
Private Const AYAR_DOSYASI As String = "yayin_ayar.txt"
Private Const LOG_DOSYASI As String = "yayin_log.txt"
Private Const SON_DOSYASI As String = "yayin_son.txt"
Private Const ILK_BEKLEME_SN As Long = 20
Private Const EN_AZ_YUKLEME_DK As Long = 6
Private Const SATIR_SAYISI As Long = 33
Private Const SUTUN_SAYISI As Long = 25

' ---- ayarlar (yayin_ayar.txt) ----
Private mRepo As String
Private mToken As String
Private mDal As String
Private mYol As String
Private mSube As String
Private mAralikDk As Long
Private mPrim As Boolean
Private mAyKorumasi As Boolean
Private mAyarOk As Boolean
Private mAyarYok As Boolean
Private mAyarHata As String

' ---- calisma durumu ----
Private mZaman As Date
Private mZamanVar As Boolean
Private mDurdu As Boolean
Private mMesgul As Boolean
Private mAtlanan As Long
Private mOnceki As String
Private mSon As String
Private mSonYuklendi As Boolean
Private mSonYukleme As Date
Private mSonYuklemeVar As Boolean
Private mBasarisiz As Long
Private mBekle As Date
Private mUyari As String
Private mSonUyari As String
Private mDurumMetni As String

'=====================================================================
'  ACILIS / KAPANIS
'=====================================================================
Public Sub Auto_Open()
    On Error Resume Next
    BaslatIc True
End Sub

Public Sub Auto_Close()
    On Error Resume Next
    ZamanlayiciIptal
End Sub

'=====================================================================
'  KULLANICI MAKROLARI
'=====================================================================
Public Sub YayinBaslat()
    BaslatIc False
End Sub

Private Sub BaslatIc(ByVal sessiz As Boolean)
    On Error GoTo Hata
    mDurdu = False
    If Not AyarOku() Then
        If sessiz And mAyarYok Then Exit Sub
        Gunluk "Yayin kapali: " & mAyarHata
        Durum "Gidi~sat yay~in~i kapal~i: " & mAyarHata
        If Not sessiz Then
            MsgBox Tr("Gidi~sat yay~in~i ba~slat~ilamad~i:") & vbCrLf & vbCrLf & Tr(mAyarHata), vbExclamation, Tr("Gidi~sat yay~in")
        End If
        Exit Sub
    End If
    mMesgul = False
    mAtlanan = 0
    mSonYuklendi = False
    ZamanlayiciKur ILK_BEKLEME_SN
    Gunluk "Yayin basladi (surum " & SURUM & ", aralik " & CStr(mAralikDk) & " dk, prim " & IIf(mPrim, "acik", "gizli") & ")"
    Durum "Gidi~sat yay~in~i a~c~ik (" & CStr(mAralikDk) & " dk'da bir kontrol eder)"
    Exit Sub
Hata:
    Gunluk "Baslat hata: " & CStr(Err.Number) & " " & Err.Description
End Sub

Public Sub YayinDurdur()
    On Error Resume Next
    mDurdu = True
    ZamanlayiciIptal
    Gunluk "Yayin durduruldu"
    Durum "Gidi~sat yay~in~i durduruldu"
End Sub

Public Sub YayinDurumu()
    Dim s As String
    On Error GoTo Hata
    If Not mAyarOk Then Call AyarOku
    If mAyarOk Then
        s = "Ayar dosyas~i: tamam" & vbCrLf
        s = s & "Depo: " & mRepo & vbCrLf
        s = s & "Kontrol aral~i~g~i: " & CStr(mAralikDk) & " dk" & vbCrLf
        s = s & "Prim bilgileri: " & IIf(mPrim, "yay~inlan~iyor", "yay~inlanm~iyor") & vbCrLf
    Else
        s = "Ayar dosyas~i: SORUNLU" & vbCrLf & mAyarHata & vbCrLf
    End If
    s = s & "Zamanlay~ic~i: " & IIf(mZamanVar, "a~c~ik", "kapal~i") & vbCrLf
    If mSonYuklemeVar Then
        s = s & "Son y~ukleme: " & ZamanMetni(mSonYukleme) & vbCrLf
    Else
        s = s & "Son y~ukleme: bu oturumda yok" & vbCrLf
    End If
    If mBasarisiz > 0 Then s = s & "Ard~i~s~ik ba~sar~is~iz deneme: " & CStr(mBasarisiz) & vbCrLf
    If mAyarOk Then s = s & vbCrLf & "Personel adresi:" & vbCrLf & SayfaAdresi() & vbCrLf
    s = Tr(s) & vbCrLf & Tr("G~unl~uk: ") & ThisWorkbook.Path & "\" & LOG_DOSYASI
    MsgBox s, vbInformation, Tr("Gidi~sat yay~in durumu")
    Exit Sub
Hata:
    MsgBox "Hata: " & Err.Description, vbExclamation
End Sub

Public Sub HemenYayinla()
    Dim kimlik As String, ts As String, tam As String, ayMetni As String
    Dim hs As Long, ds As Long, ayNo As Long, ayAtla As Boolean
    Dim sonuc As String, ok As Boolean, ileti As String
    On Error GoTo Hata
    If Not AyarOku() Then
        MsgBox Tr("Ayar dosyas~i okunamad~i:") & vbCrLf & vbCrLf & Tr(mAyarHata) & vbCrLf & vbCrLf & Tr("Klas~or: ") & ThisWorkbook.Path, vbExclamation, Tr("Gidi~sat yay~in")
        Exit Sub
    End If
    If Not Hazirla(kimlik, ts, tam, ayMetni, hs, ds) Then
        MsgBox Tr("Yay~inlanamad~i:") & vbCrLf & vbCrLf & Tr(mUyari), vbExclamation, Tr("Gidi~sat yay~in")
        Exit Sub
    End If
    If mAyKorumasi Then
        ayNo = AyNumarasi(ayMetni)
        If Not AyUygun(ayNo, Date) Then
            If MsgBox(Tr("Bu dosyan~in d~oneminde '" & ayMetni & "' yaz~iyor, ama bug~un ba~ska bir ayday~iz." & vbCrLf & vbCrLf & _
                         "Yine de yay~inlans~in m~i? (Eski bir ay dosyas~i ise HAYIR deyin.)"), _
                       vbYesNo + vbQuestion + vbDefaultButton2, Tr("Gidi~sat yay~in")) <> vbYes Then Exit Sub
            ayAtla = True
        End If
    End If
    Application.StatusBar = Tr("Gidi~sat yay~inlan~iyor...")
    ok = Yayinla(True, ayAtla, sonuc)
    DurumTemizle
    If ok Then
        ileti = "Yay~inland~i." & vbCrLf & vbCrLf & "Personelin a~caca~g~i adres (1-2 dakika sonra g~uncellenir):" & vbCrLf & SayfaAdresi()
        If hs > 0 Then ileti = ileti & vbCrLf & vbCrLf & "Uyar~i: Excel'de " & CStr(hs) & " h~ucrede hata de~geri var; bunlar bo~s g~onderildi."
        MsgBox Tr(ileti), vbInformation, Tr("Gidi~sat yay~in")
    Else
        ileti = Tr("Yay~inlanamad~i:") & vbCrLf & Tr(sonuc) & vbCrLf & vbCrLf & Tr("Ayr~int~i i~cin: ") & ThisWorkbook.Path & "\" & LOG_DOSYASI
        ileti = ileti & vbCrLf & vbCrLf & Tr("Haz~irlanan dosya: ") & ThisWorkbook.Path & "\veri\" & DosyaAdi()
        ileti = ileti & vbCrLf & Tr("(GitHub'da Add file > Upload files ile el ile y~ukleyebilirsiniz.)")
        MsgBox ileti, vbExclamation, Tr("Gidi~sat yay~in")
    End If
    If Not mZamanVar And Not mDurdu Then ZamanlayiciKur mAralikDk * 60
    Exit Sub
Hata:
    DurumTemizle
    Gunluk "HemenYayinla hata: " & CStr(Err.Number) & " " & Err.Description
    MsgBox "Hata: " & Err.Description, vbExclamation, Tr("Gidi~sat yay~in")
End Sub

'=====================================================================
'  ZAMANLAYICI
'=====================================================================
Public Sub Tik()
    Dim sonuc As String, ayarOk As Boolean
    On Error GoTo Hata
    mZamanVar = False
    If mDurdu Then Exit Sub
    ayarOk = AyarOku()
    ZamanlayiciKur mAralikDk * 60
    DurumTemizle
    If Not ayarOk Then
        UyariYaz mAyarHata
        Exit Sub
    End If
    If mMesgul Then Exit Sub
    If UygunAn() Then
        mAtlanan = 0
    Else
        mAtlanan = mAtlanan + 1
        If mAtlanan < 10 Then Exit Sub
        If mAtlanan = 10 Then Gunluk "Excel uzun suredir mesgul gorunuyor; yine de devam ediliyor"
    End If
    mMesgul = True
    Call Yayinla(False, False, sonuc)
    mMesgul = False
    Exit Sub
Hata:
    mMesgul = False
    Gunluk "Tik hata: " & CStr(Err.Number) & " " & Err.Description
End Sub

Private Function UygunAn() As Boolean
    ' Baska bir makro (ornegin RaporAktar) calisirken veya hesaplama surerken bekler.
    On Error GoTo Hata
    If Application.EnableEvents = False Then Exit Function
    If Application.CalculationState <> xlDone Then Exit Function
    UygunAn = True
    Exit Function
Hata:
    UygunAn = False
End Function

Private Function ProsedurAdi() As String
    ProsedurAdi = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!GidisatYayin.Tik"
End Function

Private Sub ZamanlayiciKur(ByVal saniye As Long)
    Dim t As Date
    On Error Resume Next
    ZamanlayiciIptal
    t = Now + saniye / 86400#
    Err.Clear
    Application.OnTime EarliestTime:=t, Procedure:=ProsedurAdi(), Schedule:=True
    If Err.Number = 0 Then
        mZaman = t
        mZamanVar = True
    Else
        mZamanVar = False
        Gunluk "Zamanlayici kurulamadi: " & CStr(Err.Number) & " " & Err.Description
    End If
End Sub

Private Sub ZamanlayiciIptal()
    On Error Resume Next
    If mZamanVar Then
        Application.OnTime EarliestTime:=mZaman, Procedure:=ProsedurAdi(), Schedule:=False
    End If
    mZamanVar = False
End Sub

'=====================================================================
'  YAYIN ISLEMI
'=====================================================================
Private Function Yayinla(ByVal zorla As Boolean, ByVal ayAtla As Boolean, ByRef sonuc As String) As Boolean
    Dim kimlik As String, ts As String, tam As String, ayMetni As String, anahtarli As String
    Dim hs As Long, ds As Long, ayNo As Long
    Dim ok As Boolean, hataMetin As String

    sonuc = ""
    If Not Hazirla(kimlik, ts, tam, ayMetni, hs, ds) Then
        sonuc = mUyari
        UyariYaz mUyari
        Exit Function
    End If

    If mAyKorumasi And Not ayAtla Then
        ayNo = AyNumarasi(ayMetni)
        If Not AyUygun(ayNo, Date) Then
            sonuc = "Bu dosyan~in d~onemi (" & ayMetni & ") bu ay de~gil; yay~inlanmad~i."
            UyariYaz sonuc
            Exit Function
        End If
    End If
    mSonUyari = ""

    anahtarli = AnahtarSatiri() & vbLf & kimlik
    If Not mSonYuklendi Then SonOku

    If Not zorla Then
        If anahtarli = mSon Then
            mOnceki = kimlik
            Yayinla = True
            Exit Function
        End If
        If kimlik <> mOnceki Then
            ' Veri az once degisti; yarim kalmis girisleri yayinlamamak icin bir tur beklenir.
            mOnceki = kimlik
            Exit Function
        End If
        If mSonYuklemeVar Then
            If Now - mSonYukleme < EN_AZ_YUKLEME_DK / 1440# Then Exit Function
        End If
        If Now < mBekle Then Exit Function
    End If

    YerelKopya tam
    ok = GitHubYukle(ts, tam, hataMetin)
    If ok Then
        mSon = anahtarli
        mSonYuklendi = True
        mSonYukleme = Now
        mSonYuklemeVar = True
        mBasarisiz = 0
        mBekle = 0
        mOnceki = kimlik
        mAtlanan = 0
        SonYaz anahtarli
        Gunluk "Yayinlandi " & ts & IIf(hs > 0, " (hatali hucre: " & CStr(hs) & ")", "") & IIf(ds > 0, " (dar sutun: " & CStr(ds) & ")", "")
        Durum "Gidi~sat yay~inland~i (" & SaatMetni(Now) & ")"
        Yayinla = True
    Else
        mBasarisiz = mBasarisiz + 1
        Select Case mBasarisiz
            Case 1: mBekle = 0
            Case 2: mBekle = Now + 5 / 1440#
            Case 3: mBekle = Now + 10 / 1440#
            Case Else: mBekle = Now + 15 / 1440#
        End Select
        Gunluk "YAYIN HATASI: " & hataMetin
        Durum "Gidi~sat yay~in~i ba~sar~is~iz: " & hataMetin
        sonuc = hataMetin
    End If
End Function

Private Sub UyariYaz(ByVal metin As String)
    ' ayni uyariyi her turda tekrar tekrar yazmaz
    If metin = mSonUyari Then Exit Sub
    mSonUyari = metin
    Gunluk "Yayin yapilmadi: " & metin
    Durum "Gidi~sat yay~in~i yap~ilmad~i: " & metin
End Sub

Private Function AnahtarSatiri() As String
    AnahtarSatiri = mRepo & "|" & mDal & "|" & mYol & "|" & DosyaAdi() & "|" & IIf(mPrim, "1", "0")
End Function

Private Function DosyaAdi() As String
    If Len(mSube) > 0 Then
        DosyaAdi = mSube & ".js"
    Else
        DosyaAdi = "veri.js"
    End If
End Function

Private Function SayfaAdresi() As String
    Dim p As Long, sahip As String, depo As String, a As String
    p = InStr(1, mRepo, "/", vbBinaryCompare)
    sahip = Left$(mRepo, p - 1)
    depo = Mid$(mRepo, p + 1)
    If AsciiBuyuk(depo) = AsciiBuyuk(sahip) & ".GITHUB.IO" Then
        a = "https://" & AsciiKucuk(sahip) & ".github.io/"
    Else
        a = "https://" & AsciiKucuk(sahip) & ".github.io/" & depo & "/"
    End If
    If Len(mSube) > 0 Then a = a & "?b=" & mSube
    SayfaAdresi = a
End Function

'=====================================================================
'  VERIYI HAZIRLA (Excel'den oku, JS metnine cevir)
'=====================================================================
Private Function Hazirla(ByRef kimlik As String, ByRef ts As String, ByRef tam As String, _
                         ByRef ayMetni As String, ByRef hataSay As Long, ByRef darSay As Long) As Boolean
    Dim ws As Worksheet, wsH As Worksheet, wsM As Worksheet, wsR As Worksheet
    Dim bayi As String, ayJ As String, gunJ As String, topJ As String, mmaJ As String
    Dim grid As String, bas As String, son As String

    Set ws = GidisatSayfa()
    If ws Is Nothing Then
        mUyari = "G~ID~I~SAT sayfas~i bulunamad~i"
        Exit Function
    End If
    If Not DuzenTamam(ws) Then
        mUyari = "G~ID~I~SAT sayfas~in~in d~uzeni beklenenden farkl~i"
        Exit Function
    End If

    Set wsR = SayfaBul("Rapor Aktar")
    If Not wsR Is Nothing Then bayi = Trim$(wsR.Range("B1").Text)

    ayJ = "null"
    gunJ = "null"
    topJ = "null"
    ayMetni = ""
    Set wsH = SayfaBul("HEDEF")
    If Not wsH Is Nothing Then
        ayMetni = Trim$(wsH.Range("V2").Text)
        If Len(ayMetni) > 0 Then ayJ = JsonMetin(ayMetni)
        gunJ = SayiJson(wsH.Range("V3").Value2)
        topJ = SayiJson(wsH.Range("V4").Value2)
    End If

    mmaJ = "null"
    Set wsM = SayfaBul("MMA")
    If Not wsM Is Nothing Then mmaJ = SayiJson(wsM.Range("AB6").Value2)

    hataSay = 0
    darSay = 0
    grid = GridJson(ws, hataSay, darSay)
    ts = ZamanMetni(Now)

    bas = "window.GIDISAT_VERI={""s"":1,""bayi"":" & JsonMetin(bayi)
    son = ",""donem"":{""ay"":" & ayJ & ",""gun"":" & gunJ & ",""top"":" & topJ & "}"
    son = son & ",""mma"":" & mmaJ
    son = son & ",""prim"":" & IIf(mPrim, "1", "0")
    son = son & ",""hata"":" & CStr(hataSay)
    son = son & ",""g"":" & grid & "};"
    kimlik = bas & son
    tam = bas & ",""ts"":""" & ts & """" & son
    Hazirla = True
End Function

Private Function GidisatSayfa() As Worksheet
    Dim ws As Worksheet, ad As String
    ad = "G" & ChrW(304) & "D" & ChrW(304) & ChrW(350) & "AT"
    For Each ws In ThisWorkbook.Worksheets
        If ws.Name = ad Then
            Set GidisatSayfa = ws
            Exit Function
        End If
    Next ws
    For Each ws In ThisWorkbook.Worksheets
        If ws.CodeName = "Sayfa4" Then
            Set GidisatSayfa = ws
            Exit Function
        End If
    Next ws
End Function

Private Function SayfaBul(ByVal ad As String) As Worksheet
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If ws.Name = ad Then
            Set SayfaBul = ws
            Exit Function
        End If
    Next ws
End Function

Private Function DuzenTamam(ByVal ws As Worksheet) As Boolean
    ' Sayfanin duzeni degistiyse yanlis veri gondermemek icin kontrol eder.
    If MetinAl(ws.Cells(2, 1)) <> "Personel" Then Exit Function
    If MetinAl(ws.Cells(18, 1)) <> "Personel" Then Exit Function
    If Right$(MetinAl(ws.Cells(16, 1)), 7) <> "TOPLAMI" Then Exit Function
    If Right$(MetinAl(ws.Cells(32, 1)), 7) <> "TOPLAMI" Then Exit Function
    DuzenTamam = True
End Function

Private Function MetinAl(ByVal hucre As Range) As String
    Dim v As Variant
    v = hucre.Value2
    If IsError(v) Then Exit Function
    If IsEmpty(v) Then Exit Function
    MetinAl = Trim$(CStr(v))
End Function

Private Function GridJson(ByVal ws As Worksheet, ByRef hataSay As Long, ByRef darSay As Long) As String
    Dim arr As Variant, r As Long, c As Long
    Dim satir As String, tum As String
    arr = ws.Range(ws.Cells(1, 1), ws.Cells(SATIR_SAYISI, SUTUN_SAYISI)).Value2
    tum = "["
    For r = 1 To SATIR_SAYISI
        satir = "["
        For c = 1 To SUTUN_SAYISI
            If c > 1 Then satir = satir & ","
            satir = satir & HucreJson(ws, arr(r, c), r, c, hataSay, darSay)
        Next c
        If r > 1 Then tum = tum & "," & vbLf
        tum = tum & satir & "]"
    Next r
    GridJson = tum & "]"
End Function

Private Function HucreJson(ByVal ws As Worksheet, ByVal v As Variant, ByVal r As Long, ByVal c As Long, _
                           ByRef hataSay As Long, ByRef darSay As Long) As String
    Dim t As String
    HucreJson = "null"
    If PrimGizli(r, c) Then Exit Function
    If IsError(v) Then
        hataSay = hataSay + 1
        Exit Function
    End If
    If IsEmpty(v) Then Exit Function
    Select Case VarType(v)
        Case vbString
            If Len(v) > 0 Then HucreJson = "[" & JsonMetin(CStr(v)) & "," & JsonMetin("") & "]"
        Case vbBoolean
            t = Trim$(ws.Cells(r, c).Text)
            HucreJson = "[" & IIf(v, "true", "false") & "," & JsonMetin(t) & "]"
        Case vbDouble
            t = Trim$(ws.Cells(r, c).Text)
            If TumuDiyez(t) Then
                t = ""
                darSay = darSay + 1
            End If
            HucreJson = "[" & SayiMetni(CDbl(v)) & "," & JsonMetin(t) & "]"
    End Select
End Function

Private Function PrimGizli(ByVal r As Long, ByVal c As Long) As Boolean
    ' PRIM_YAYINLA=HAYIR ise kisilerin prim tutarlari yayina gitmez.
    ' Kesinti durumu basliklari (T19 ve X19) sube duzeyinde oldugu icin kalir.
    If mPrim Then Exit Function
    If r < 19 Or r > 32 Then Exit Function
    Select Case c
        Case 6, 7, 16, 18, 19, 21, 22, 23, 25
            PrimGizli = True
        Case 20, 24
            PrimGizli = (r <> 19)
    End Select
End Function

Private Function TumuDiyez(ByVal s As String) As Boolean
    Dim i As Long
    If Len(s) = 0 Then Exit Function
    For i = 1 To Len(s)
        If Mid$(s, i, 1) <> "#" Then Exit Function
    Next i
    TumuDiyez = True
End Function

Private Function SayiJson(ByVal v As Variant) As String
    SayiJson = "null"
    If IsError(v) Then Exit Function
    If VarType(v) = vbDouble Then SayiJson = SayiMetni(CDbl(v))
End Function

'=====================================================================
'  GITHUB
'=====================================================================
Private Function GitHubYukle(ByVal ts As String, ByVal tam As String, ByRef sonuc As String) As Boolean
    Dim url As String, yanit As String, sha As String, b64 As String, govde As String
    Dim durum As Long, deneme As Long

    url = "https://api.github.com/repos/" & mRepo & "/contents/" & mYol & "/" & DosyaAdi()
    b64 = Base64Kodla(tam)

    For deneme = 1 To 2
        durum = HttpIstek("GET", url & "?ref=" & mDal & "&t=" & CStr(Int(Timer * 100)), "", yanit)
        sha = ""
        If durum = 200 Then
            sha = JsonDeger(yanit, "sha")
            If Len(sha) = 0 Then
                sonuc = "GitHub yan~it~i okunamad~i (sha yok)"
                Exit Function
            End If
        ElseIf durum = 404 Then
            sha = ""
        Else
            sonuc = HataMetni(durum, yanit)
            Exit Function
        End If

        govde = "{""message"":""Gidisat " & ts & """,""content"":""" & b64 & """,""branch"":""" & mDal & """"
        If Len(sha) > 0 Then govde = govde & ",""sha"":""" & sha & """"
        govde = govde & "}"

        durum = HttpIstek("PUT", url, govde, yanit)
        If durum = 200 Or durum = 201 Then
            GitHubYukle = True
            Exit Function
        End If
        If Not ((durum = 409 Or durum = 422) And deneme = 1) Then
            sonuc = HataMetni(durum, yanit)
            Exit Function
        End If
    Next deneme
End Function

Private Function HttpIstek(ByVal metot As String, ByVal url As String, ByVal govde As String, ByRef yanit As String) As Long
    Dim http As Object
    On Error GoTo Hata
    yanit = ""
    Set http = HttpNesne()
    If http Is Nothing Then
        yanit = "MSXML bulunamad~i"
        Exit Function
    End If
    http.Open metot, url, False
    http.setRequestHeader "Authorization", "Bearer " & mToken
    http.setRequestHeader "Accept", "application/vnd.github+json"
    http.setRequestHeader "X-GitHub-Api-Version", "2022-11-28"
    http.setRequestHeader "User-Agent", "GidisatYayin/" & SURUM
    http.setRequestHeader "Cache-Control", "no-cache"
    http.setRequestHeader "Pragma", "no-cache"
    If metot = "GET" Then
        http.setRequestHeader "If-Modified-Since", "Sat, 01 Jan 2000 00:00:00 GMT"
        http.Send
    Else
        http.setRequestHeader "Content-Type", "application/json"
        http.Send govde
    End If
    HttpIstek = http.Status
    yanit = http.responseText
    Exit Function
Hata:
    HttpIstek = 0
    yanit = "Ba~glant~i kurulamad~i (hata " & CStr(Err.Number) & ")"
End Function

Private Function HttpNesne() As Object
    Dim o As Object, adlar As Variant, i As Long
    adlar = Array("MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP")
    For i = LBound(adlar) To UBound(adlar)
        On Error Resume Next
        Set o = Nothing
        Set o = CreateObject(CStr(adlar(i)))
        On Error GoTo 0
        If Not o Is Nothing Then Exit For
    Next i
    Set HttpNesne = o
End Function

Private Function HataMetni(ByVal durum As Long, ByVal yanit As String) As String
    Dim ipucu As String, ileti As String
    If durum = 0 Then
        HataMetni = yanit
        Exit Function
    End If
    ileti = JsonDeger(yanit, "message")
    Select Case durum
        Case 401: ipucu = "Eri~sim anahtar~i ge~cersiz ya da s~uresi dolmu~s (GITHUB_TOKEN)."
        Case 403: ipucu = "Yetki yok ya da istek limiti a~s~ild~i. Anahtar~in 'Contents: Read and write' izni var m~i?"
        Case 404: ipucu = "Depo ya da dal bulunamad~i (GITHUB_REPO, DAL) veya anahtar bu depoya izinli de~gil."
        Case 409, 422: ipucu = "GitHub iste~gi reddetti; birka~c dakika sonra yeniden denenir."
        Case Else: ipucu = ""
    End Select
    HataMetni = "HTTP " & CStr(durum) & IIf(Len(ileti) > 0, " (" & ileti & ")", "")
    If Len(ipucu) > 0 Then HataMetni = HataMetni & ". " & ipucu
End Function

Private Function JsonDeger(ByVal js As String, ByVal anahtar As String) As String
    Dim p As Long, q As Long, n As Long, ch As String
    p = InStr(1, js, """" & anahtar & """", vbBinaryCompare)
    If p = 0 Then Exit Function
    p = p + Len(anahtar) + 2
    n = Len(js)
    Do While p <= n
        ch = Mid$(js, p, 1)
        If ch = " " Or ch = ":" Or ch = vbTab Or ch = vbCr Or ch = vbLf Then
            p = p + 1
        Else
            Exit Do
        End If
    Loop
    If p > n Then Exit Function
    If Mid$(js, p, 1) <> """" Then Exit Function
    q = InStr(p + 1, js, """", vbBinaryCompare)
    If q = 0 Then Exit Function
    JsonDeger = Mid$(js, p + 1, q - p - 1)
End Function

'=====================================================================
'  AYAR DOSYASI
'=====================================================================
Private Function AyarOku() As Boolean
    Dim yol As String, f As Integer, metin As String, parca() As String, i As Long
    mAyarOk = False
    mAyarYok = False
    mAyarHata = ""
    mRepo = ""
    mToken = ""
    mDal = "main"
    mYol = "veri"
    mSube = ""
    mAralikDk = 3
    mPrim = False
    mAyKorumasi = True

    If Len(ThisWorkbook.Path) = 0 Then
        mAyarYok = True
        mAyarHata = "Excel dosyas~i hen~uz kaydedilmemi~s."
        Exit Function
    End If
    yol = ThisWorkbook.Path & "\" & AYAR_DOSYASI
    If Len(Dir$(yol)) = 0 Then
        mAyarYok = True
        mAyarHata = AYAR_DOSYASI & " dosyas~i Excel dosyas~in~in bulundu~gu klas~orde yok."
        Exit Function
    End If

    On Error GoTo Hata
    f = FreeFile
    Open yol For Binary Access Read As #f
    If LOF(f) > 0 Then metin = Input$(LOF(f), f)
    Close #f
    On Error GoTo 0
    metin = Replace(metin, Chr$(0), "")
    metin = Replace(metin, vbCrLf, vbLf)
    metin = Replace(metin, vbCr, vbLf)
    parca = Split(metin, vbLf)
    For i = LBound(parca) To UBound(parca)
        AyarSatiriIsle parca(i)
    Next i

    mAyarHata = AyarDogrula()
    mAyarOk = (Len(mAyarHata) = 0)
    AyarOku = mAyarOk
    Exit Function
Hata:
    On Error Resume Next
    Close #f
    mAyarHata = AYAR_DOSYASI & " okunamad~i."
End Function

Private Sub AyarSatiriIsle(ByVal satir As String)
    Dim p As Long, anahtar As String, deger As String, n As Long
    ' dosya basindaki gorunmez isaretleri (BOM) ve ASCII disi karakterleri at
    Do While Len(satir) > 0
        n = AscW(Left$(satir, 1)) And &HFFFF&
        If n < 33 Or n > 126 Then
            satir = Mid$(satir, 2)
        Else
            Exit Do
        End If
    Loop
    satir = Trim$(satir)
    If Len(satir) = 0 Then Exit Sub
    If Left$(satir, 1) = "#" Or Left$(satir, 1) = ";" Then Exit Sub
    p = InStr(1, satir, "=", vbBinaryCompare)
    If p < 2 Then Exit Sub
    anahtar = AsciiBuyuk(Trim$(Left$(satir, p - 1)))
    deger = Mid$(satir, p + 1)
    ' degerin basindaki ve sonundaki bosluk, sekme, gorunmez isaret gibi karakterleri at
    Do While Len(deger) > 0
        n = AscW(Right$(deger, 1)) And &HFFFF&
        If n < 33 Or n > 126 Then
            deger = Left$(deger, Len(deger) - 1)
        Else
            Exit Do
        End If
    Loop
    Do While Len(deger) > 0
        n = AscW(Left$(deger, 1)) And &HFFFF&
        If n < 33 Or n > 126 Then
            deger = Mid$(deger, 2)
        Else
            Exit Do
        End If
    Loop
    If Len(deger) >= 2 Then
        If Left$(deger, 1) = """" And Right$(deger, 1) = """" Then deger = Trim$(Mid$(deger, 2, Len(deger) - 2))
    End If
    Select Case anahtar
        Case "GITHUB_REPO": mRepo = deger
        Case "GITHUB_TOKEN": mToken = deger
        Case "DAL": If Len(deger) > 0 Then mDal = deger
        Case "YOL": If Len(deger) > 0 Then mYol = deger
        Case "SUBE_KODU": mSube = deger
        Case "ARALIK_DK"
            n = CLng(Val(deger))
            If n >= 2 Then
                If n > 60 Then n = 60
                mAralikDk = n
            End If
        Case "PRIM_YAYINLA": mPrim = (AsciiBuyuk(deger) = "EVET")
        Case "AY_KORUMASI": mAyKorumasi = (AsciiBuyuk(deger) <> "HAYIR")
    End Select
End Sub

Private Function AyarDogrula() As String
    ' Sorun yoksa "" doner, varsa aciklama doner.
    Dim p As Long
    Do While Left$(mYol, 1) = "/"
        mYol = Mid$(mYol, 2)
    Loop
    Do While Right$(mYol, 1) = "/"
        mYol = Left$(mYol, Len(mYol) - 1)
    Loop
    If Len(mRepo) = 0 Or Len(mToken) = 0 Then
        AyarDogrula = "GITHUB_REPO ve GITHUB_TOKEN sat~irlar~i doldurulmal~i."
        Exit Function
    End If
    If InStr(1, mRepo, "KULLANICI", vbBinaryCompare) > 0 Or Left$(mToken, 6) = "BURAYA" Then
        AyarDogrula = AYAR_DOSYASI & " hen~uz doldurulmam~i~s: KULLANICI ve BURAYA ile ba~slayan yaz~ilar~i kendi bilgilerinizle de~gi~stirin."
        Exit Function
    End If
    p = InStr(1, mRepo, "/", vbBinaryCompare)
    If p < 2 Or InStr(p + 1, mRepo, "/", vbBinaryCompare) > 0 Or p = Len(mRepo) Then
        AyarDogrula = "GITHUB_REPO 'kullan~ic~i/depo' bi~ciminde olmal~i."
        Exit Function
    End If
    If Not TemizAd(Left$(mRepo, p - 1), False) Or Not TemizAd(Mid$(mRepo, p + 1), False) Then
        AyarDogrula = "GITHUB_REPO i~cinde ge~cersiz karakter var."
        Exit Function
    End If
    If Not TemizAd(mToken, False) Then
        AyarDogrula = "GITHUB_TOKEN i~cinde ge~cersiz karakter var (bo~sluk ya da gizli i~saret olabilir; yeniden yap~i~st~ir~in)."
        Exit Function
    End If
    If Not TemizAd(mDal, True) Then
        AyarDogrula = "DAL ge~cersiz."
        Exit Function
    End If
    If Not TemizAd(mYol, True) Then
        AyarDogrula = "YOL ge~cersiz."
        Exit Function
    End If
    If Len(mSube) > 0 Then
        If Not TemizAd(mSube, False) Then
            AyarDogrula = "SUBE_KODU yaln~izca harf, rakam, nokta, '-' ve '_' i~cermeli."
            Exit Function
        End If
    End If
End Function

Private Function TemizAd(ByVal s As String, ByVal slashIzin As Boolean) As Boolean
    Dim i As Long, ch As Long
    If Len(s) = 0 Then Exit Function
    For i = 1 To Len(s)
        ch = AscW(Mid$(s, i, 1)) And &HFFFF&
        If Not ((ch >= 48 And ch <= 57) Or (ch >= 65 And ch <= 90) Or (ch >= 97 And ch <= 122) _
                Or ch = 46 Or ch = 95 Or ch = 45 Or (slashIzin And ch = 47)) Then Exit Function
    Next i
    TemizAd = True
End Function

'=====================================================================
'  YEREL DOSYALAR (kopya, son durum, gunluk)
'=====================================================================
Private Sub YerelKopya(ByVal tam As String)
    Dim klasor As String, f As Integer
    On Error GoTo Hata
    klasor = ThisWorkbook.Path & "\veri"
    If Len(Dir$(klasor, vbDirectory)) = 0 Then MkDir klasor
    f = FreeFile
    Open klasor & "\" & DosyaAdi() For Output As #f
    Print #f, tam;
    Close #f
    Exit Sub
Hata:
    On Error Resume Next
    Close #f
    Gunluk "Yerel kopya yaz~ilamad~i: " & Err.Description
End Sub

Private Sub SonOku()
    Dim yol As String, f As Integer
    mSonYuklendi = True
    mSon = ""
    On Error GoTo Hata
    yol = ThisWorkbook.Path & "\" & SON_DOSYASI
    If Len(Dir$(yol)) = 0 Then Exit Sub
    f = FreeFile
    Open yol For Binary Access Read As #f
    If LOF(f) > 0 Then mSon = Input$(LOF(f), f)
    Close #f
    Exit Sub
Hata:
    On Error Resume Next
    Close #f
    mSon = ""
End Sub

Private Sub SonYaz(ByVal metin As String)
    Dim f As Integer
    On Error GoTo Hata
    f = FreeFile
    Open ThisWorkbook.Path & "\" & SON_DOSYASI For Output As #f
    Print #f, metin;
    Close #f
    Exit Sub
Hata:
    On Error Resume Next
    Close #f
End Sub

Private Sub Gunluk(ByVal metin As String)
    Dim yol As String, f As Integer
    On Error Resume Next
    If Len(ThisWorkbook.Path) = 0 Then Exit Sub
    yol = ThisWorkbook.Path & "\" & LOG_DOSYASI
    If Len(Dir$(yol)) > 0 Then
        If FileLen(yol) > 200000 Then
            Kill ThisWorkbook.Path & "\yayin_log_eski.txt"
            Name yol As ThisWorkbook.Path & "\yayin_log_eski.txt"
        End If
    End If
    f = FreeFile
    Open yol For Append As #f
    Print #f, ZamanMetni(Now) & " " & Replace(metin, "~", "")
    Close #f
End Sub

Private Sub Durum(ByVal metin As String)
    On Error Resume Next
    mDurumMetni = Tr(metin)
    Application.StatusBar = mDurumMetni
End Sub

Private Sub DurumTemizle()
    On Error Resume Next
    If Len(mDurumMetni) = 0 Then Exit Sub
    If VarType(Application.StatusBar) = vbString Then
        If Application.StatusBar = mDurumMetni Then Application.StatusBar = False
    End If
    mDurumMetni = ""
End Sub

'=====================================================================
'  YARDIMCI ISLEVLER (Excel'e bagli degildir)
'  --- BASLANGIC: yardimci ---
'=====================================================================
Private Function JsonMetin(ByVal s As String) As String
    ' Metni tirnakli, yalnizca ASCII karakterli JSON metnine cevirir.
    Dim i As Long, n As Long, ch As Long, o As String
    n = Len(s)
    o = """"
    For i = 1 To n
        ch = AscW(Mid$(s, i, 1))
        If ch < 0 Then ch = ch + 65536
        Select Case ch
            Case 34
                o = o & "\"""
            Case 92
                o = o & "\\"
            Case 8
                o = o & "\b"
            Case 9
                o = o & "\t"
            Case 10
                o = o & "\n"
            Case 12
                o = o & "\f"
            Case 13
                o = o & "\r"
            Case Is < 32, Is > 126
                o = o & "\u" & Right$("0000" & Hex$(ch), 4)
            Case Else
                o = o & Chr$(ch)
        End Select
    Next i
    JsonMetin = o & """"
End Function

Private Function SayiMetni(ByVal d As Double) As String
    ' Bolgesel ayardan bagimsiz, nokta ondalikli sayi metni.
    Dim s As String
    s = Trim$(Str$(d))
    If Left$(s, 1) = "." Then s = "0" & s
    If Left$(s, 2) = "-." Then s = "-0" & Mid$(s, 2)
    SayiMetni = s
End Function

Private Function Base64Kodla(ByVal s As String) As String
    Const TBL As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    Dim b() As Byte, n As Long, i As Long, o As Long, ch As Long
    Dim b0 As Long, b1 As Long, b2 As Long
    Dim res As String
    n = Len(s)
    If n = 0 Then Exit Function
    ReDim b(0 To n - 1)
    For i = 1 To n
        ch = AscW(Mid$(s, i, 1)) And &HFFFF&
        If ch > 127 Then ch = 63
        b(i - 1) = CByte(ch)
    Next i
    res = Space$(((n + 2) \ 3) * 4)
    o = 1
    For i = 0 To n - 1 Step 3
        b0 = b(i)
        If i + 1 < n Then b1 = b(i + 1) Else b1 = 0
        If i + 2 < n Then b2 = b(i + 2) Else b2 = 0
        Mid$(res, o, 1) = Mid$(TBL, (b0 \ 4) + 1, 1)
        Mid$(res, o + 1, 1) = Mid$(TBL, (((b0 And 3) * 16) Or (b1 \ 16)) + 1, 1)
        If i + 1 < n Then
            Mid$(res, o + 2, 1) = Mid$(TBL, (((b1 And 15) * 4) Or (b2 \ 64)) + 1, 1)
        Else
            Mid$(res, o + 2, 1) = "="
        End If
        If i + 2 < n Then
            Mid$(res, o + 3, 1) = Mid$(TBL, (b2 And 63) + 1, 1)
        Else
            Mid$(res, o + 3, 1) = "="
        End If
        o = o + 4
    Next i
    Base64Kodla = res
End Function

Private Function AsciiBuyuk(ByVal s As String) As String
    ' Turkce i/I sorunu olmasin diye yalnizca a-z harflerini buyutur.
    Dim i As Long, ch As Long, o As String
    o = s
    For i = 1 To Len(s)
        ch = AscW(Mid$(s, i, 1)) And &HFFFF&
        If ch >= 97 And ch <= 122 Then Mid$(o, i, 1) = Chr$(ch - 32)
    Next i
    AsciiBuyuk = o
End Function

Private Function AsciiKucuk(ByVal s As String) As String
    Dim i As Long, ch As Long, o As String
    o = s
    For i = 1 To Len(s)
        ch = AscW(Mid$(s, i, 1)) And &HFFFF&
        If ch >= 65 And ch <= 90 Then Mid$(o, i, 1) = Chr$(ch + 32)
    Next i
    AsciiKucuk = o
End Function

Private Function AyNumarasi(ByVal s As String) As Long
    ' Ay adini (Ocak, KASIM, mayis ...) 1-12 sayisina cevirir; tanimazsa 0 doner.
    ' ASCII disi harfler ve I harfi atilir, boylece yazim bicimi onemli olmaz.
    Dim i As Long, ch As Long, k As String
    For i = 1 To Len(s)
        ch = AscW(Mid$(s, i, 1)) And &HFFFF&
        If ch >= 97 And ch <= 122 Then ch = ch - 32
        If ch >= 65 And ch <= 90 And ch <> 73 Then k = k & Chr$(ch)
    Next i
    Select Case k
        Case "OCAK": AyNumarasi = 1
        Case "UBAT", "SUBAT": AyNumarasi = 2
        Case "MART": AyNumarasi = 3
        Case "NSAN": AyNumarasi = 4
        Case "MAYS": AyNumarasi = 5
        Case "HAZRAN": AyNumarasi = 6
        Case "TEMMUZ": AyNumarasi = 7
        Case "AUSTOS", "AGUSTOS": AyNumarasi = 8
        Case "EYLL", "EYLUL": AyNumarasi = 9
        Case "EKM": AyNumarasi = 10
        Case "KASM": AyNumarasi = 11
        Case "ARALK": AyNumarasi = 12
    End Select
End Function

Private Function AyUygun(ByVal ayNo As Long, ByVal bugun As Date) As Boolean
    ' Dosyanin donemi yayina uygun mu? Ay adi taninmazsa engellemez.
    ' Ayin ilk 3 gunu bir onceki ayin dosyasi da yayinlanabilir (son gunun verisi ay basinda girilir).
    Dim onceki As Long
    If ayNo = 0 Then
        AyUygun = True
    ElseIf ayNo = Month(bugun) Then
        AyUygun = True
    ElseIf Day(bugun) <= 3 Then
        onceki = Month(bugun) - 1
        If onceki = 0 Then onceki = 12
        AyUygun = (ayNo = onceki)
    End If
End Function

Private Function ZamanMetni(ByVal t As Date) As String
    ZamanMetni = Right$("000" & CStr(Year(t)), 4) & "-" & Right$("0" & CStr(Month(t)), 2) & "-" & Right$("0" & CStr(Day(t)), 2) & _
                 " " & Right$("0" & CStr(Hour(t)), 2) & ":" & Right$("0" & CStr(Minute(t)), 2) & ":" & Right$("0" & CStr(Second(t)), 2)
End Function

Private Function SaatMetni(ByVal t As Date) As String
    SaatMetni = Right$("0" & CStr(Hour(t)), 2) & ":" & Right$("0" & CStr(Minute(t)), 2)
End Function

Private Function Tr(ByVal s As String) As String
    ' "~i" -> i-noktasiz, "~s" -> s-cengelli ... (ASCII kaynak dosya icin kisayol)
    Dim i As Long, n As Long, k As Long, o As String
    n = Len(s)
    i = 1
    Do While i <= n
        If Mid$(s, i, 1) = "~" And i < n Then
            k = InStr(1, "iIsSgGuUoOcC", Mid$(s, i + 1, 1), vbBinaryCompare)
            If k > 0 Then
                o = o & ChrW(Choose(k, 305, 304, 351, 350, 287, 286, 252, 220, 246, 214, 231, 199))
                i = i + 2
            Else
                o = o & "~"
                i = i + 1
            End If
        Else
            o = o & Mid$(s, i, 1)
            i = i + 1
        End If
    Loop
    Tr = o
End Function
'  --- BITIS: yardimci ---
